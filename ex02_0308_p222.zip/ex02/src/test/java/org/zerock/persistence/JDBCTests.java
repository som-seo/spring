package org.zerock.persistence;

public class JDBCTests {

}
